<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Pagina de Login</title>
</head>

<body>
	<form action="recebe_login2.php" method="POST">
		<div align="center">
			Login:<input type="text" name="login" id="login"><br>
			Senha:<input type="password" name="senha" id="senha"><br><br>
	<input type="submit" value="Ok">
		</div>
	</form>
</body>
</html>
