<?php
$host = "localhost";
$user = "root";
$pass = "password";
$banco = "acessoria_esportiva";
$conexao = mysql_connect($host, $user, $pass) or die(mysql_error());
mysql_select_db($banco) or die (mysql_error());
?>

<html>
<head>
<meta charset="utf-8">
<title> autenticando usuario</title>
<script type="text/javascript">
function loginOk(){
	setTimeout("window.location='painel2.php'", 3000);
}
function loginfail(){
	setTimeout("window.location='formulario_login.php'", 3000);
}
</script>
</head>
<body>

<?php
$login = $_POST['login'];	//recebe o login
$senha = $_POST['senha'];	//recebe a senha

$sql = mysql_query ("SELECT * FROM usuario WHERE login = '$login' AND senha = '$senha'") or die(Mysql_error());

$row = mysql_num_rows($sql);

if($row > 0) {
	session_start();
	 $_SESSION['login'] =$_POST['login'];
	$_SESSION['senha'] = $_POST['senha'];
		echo "Você foi logado com sucesso! Aguarde um instante.";
		echo "<script>loginOk();</script>";

}else{
	echo "Nome de usuario ou senha invalidos! Aguarde você vai ser redirecionado!!!";
	echo "<script>loginfail();</script>";
}


?>
</body>
</html>
